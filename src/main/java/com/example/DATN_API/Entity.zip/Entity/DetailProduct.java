package com.example.DATN_API.Entity;

public class DetailProduct {
}
